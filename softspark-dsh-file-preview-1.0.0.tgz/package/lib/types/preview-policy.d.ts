/**
 * Return paths established by successful write/edit events in one session.
 * Native calls require a later matching successful result. Parsing fails closed.
 * @param events - immutable session event stream.
 * @param cwd - absolute session working directory used for relative paths.
 */
export declare function successfulMutationPaths(events: readonly unknown[], cwd?: string): readonly string[];
//# sourceMappingURL=preview-policy.d.ts.map