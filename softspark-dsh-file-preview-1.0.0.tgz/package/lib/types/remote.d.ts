/**
 * The Remote face of this package's host service.
 *
 * The harness normally generates this from the compiled host types, but the
 * generator only emits for packages that sit *below* a workspace root, and this
 * is a single-package repository. Rather than reshape the repository around
 * someone else's build layout, the descriptor is written here — one method with
 * a closed result type is small enough to own.
 *
 * `tests/remote.spec.ts` is what keeps it honest: it drives representative
 * payloads through both these schemas and the TypeScript types, so a change to
 * one that is not mirrored in the other fails the suite instead of shipping.
 * @module @softspark/dsh-file-preview/remote
 */
import { z } from 'zod';
/** Wire schemas, exported so the drift test can reach them by name. */
export declare const schemas: {
    readonly request: z.ZodObject<{
        sessionId: z.ZodReadonly<z.ZodString>;
        path: z.ZodReadonly<z.ZodString>;
    }, z.core.$strip>;
    readonly preview: z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
        kind: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"text">, z.ZodLiteral<"html">, z.ZodLiteral<"svg">]>>;
        mimeType: z.ZodReadonly<z.ZodString>;
        content: z.ZodReadonly<z.ZodString>;
        size: z.ZodReadonly<z.ZodNumber>;
    }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
        kind: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"image">, z.ZodLiteral<"pdf">]>>;
        mimeType: z.ZodReadonly<z.ZodString>;
        contentBase64: z.ZodReadonly<z.ZodString>;
        size: z.ZodReadonly<z.ZodNumber>;
    }, z.core.$strip>>]>;
    readonly failure: z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
        code: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"preview-not-found">, z.ZodLiteral<"preview-not-file">, z.ZodLiteral<"preview-outside-workspace">, z.ZodLiteral<"permission-denied">, z.ZodLiteral<"io-error">]>>;
        path: z.ZodReadonly<z.ZodString>;
    }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
        code: z.ZodReadonly<z.ZodLiteral<"preview-unsupported">>;
        path: z.ZodReadonly<z.ZodString>;
        mimeType: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
        code: z.ZodReadonly<z.ZodLiteral<"preview-too-large">>;
        path: z.ZodReadonly<z.ZodString>;
        size: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>]>;
    readonly result: z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
        ok: z.ZodReadonly<z.ZodLiteral<true>>;
        value: z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
            kind: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"text">, z.ZodLiteral<"html">, z.ZodLiteral<"svg">]>>;
            mimeType: z.ZodReadonly<z.ZodString>;
            content: z.ZodReadonly<z.ZodString>;
            size: z.ZodReadonly<z.ZodNumber>;
        }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
            kind: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"image">, z.ZodLiteral<"pdf">]>>;
            mimeType: z.ZodReadonly<z.ZodString>;
            contentBase64: z.ZodReadonly<z.ZodString>;
            size: z.ZodReadonly<z.ZodNumber>;
        }, z.core.$strip>>]>;
    }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
        ok: z.ZodReadonly<z.ZodLiteral<false>>;
        error: z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
            code: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"preview-not-found">, z.ZodLiteral<"preview-not-file">, z.ZodLiteral<"preview-outside-workspace">, z.ZodLiteral<"permission-denied">, z.ZodLiteral<"io-error">]>>;
            path: z.ZodReadonly<z.ZodString>;
        }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
            code: z.ZodReadonly<z.ZodLiteral<"preview-unsupported">>;
            path: z.ZodReadonly<z.ZodString>;
            mimeType: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
            code: z.ZodReadonly<z.ZodLiteral<"preview-too-large">>;
            path: z.ZodReadonly<z.ZodString>;
            size: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>]>;
    }, z.core.$strip>>]>;
};
/** The descriptor the browser half mounts onto `ctx.remote`. */
export declare const TYPERT_REMOTE: {
    readonly package: "@softspark/dsh-file-preview";
    readonly descriptors: readonly [{
        readonly id: "@softspark/dsh-file-preview#filePreview/previewFile";
        readonly service: "filePreview";
        readonly namespace: "filePreview";
        readonly method: "previewFile";
        readonly invocation: {
            readonly kind: "direct";
        };
        readonly parameters: readonly [{
            readonly name: "input";
            readonly wire: "input";
            readonly source: "json";
            readonly codec: {
                readonly mode: "strict";
                readonly typeSymbol: "@softspark/dsh-file-preview/types#FilePreviewRequest";
                readonly schema: z.ZodObject<{
                    sessionId: z.ZodReadonly<z.ZodString>;
                    path: z.ZodReadonly<z.ZodString>;
                }, z.core.$strip>;
            };
        }];
        readonly cancellation: {
            readonly parameter: "signal";
        };
        readonly result: {
            readonly mode: "strict";
            readonly typeSymbol: "@softspark/dsh-file-preview/types#FilePreviewResult";
            readonly schema: z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
                ok: z.ZodReadonly<z.ZodLiteral<true>>;
                value: z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
                    kind: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"text">, z.ZodLiteral<"html">, z.ZodLiteral<"svg">]>>;
                    mimeType: z.ZodReadonly<z.ZodString>;
                    content: z.ZodReadonly<z.ZodString>;
                    size: z.ZodReadonly<z.ZodNumber>;
                }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
                    kind: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"image">, z.ZodLiteral<"pdf">]>>;
                    mimeType: z.ZodReadonly<z.ZodString>;
                    contentBase64: z.ZodReadonly<z.ZodString>;
                    size: z.ZodReadonly<z.ZodNumber>;
                }, z.core.$strip>>]>;
            }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
                ok: z.ZodReadonly<z.ZodLiteral<false>>;
                error: z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
                    code: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"preview-not-found">, z.ZodLiteral<"preview-not-file">, z.ZodLiteral<"preview-outside-workspace">, z.ZodLiteral<"permission-denied">, z.ZodLiteral<"io-error">]>>;
                    path: z.ZodReadonly<z.ZodString>;
                }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
                    code: z.ZodReadonly<z.ZodLiteral<"preview-unsupported">>;
                    path: z.ZodReadonly<z.ZodString>;
                    mimeType: z.ZodOptional<z.ZodString>;
                }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
                    code: z.ZodReadonly<z.ZodLiteral<"preview-too-large">>;
                    path: z.ZodReadonly<z.ZodString>;
                    size: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strip>>]>;
            }, z.core.$strip>>]>;
        };
    }];
};
export default TYPERT_REMOTE;
//# sourceMappingURL=remote.d.ts.map