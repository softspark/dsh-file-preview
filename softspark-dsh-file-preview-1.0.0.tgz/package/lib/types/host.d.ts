/**
 * Session-authorized file preview over the host filesystem seam.
 *
 * The whole surface is one Remote. A browser may read a file only when the
 * addressed session can already reach it: either the file sits inside that
 * session's workspace, or that session itself produced it through a successful
 * write or edit. Authorization is decided here from session facts, never from
 * anything the client sends, because a client-supplied allowlist would turn a
 * preview into an arbitrary host-file read.
 * @module @softspark/dsh-file-preview
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { type FilePreviewRequest, type FilePreviewResult } from './types.ts';
export type * from './types.ts';
/** Remote-only service exposing one session-authorized preview operation. */
export declare class FilePreviewGateway extends TypertRemoteService {
    static inject: string[];
    constructor(ctx: Context);
    /**
     * Read one authorized file into a bounded, transport-safe payload.
     * @param input - the addressed session and the path as the conversation spelled it.
     * @param signal - caller lifetime; abort stops the read.
     * @returns the payload, or a failure that never carries file content.
     */
    previewFile(input: FilePreviewRequest, signal?: AbortSignal): Promise<FilePreviewResult>;
}
export default FilePreviewGateway;
//# sourceMappingURL=host.d.ts.map