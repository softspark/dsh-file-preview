import type { FilePreview } from './types.ts';
/** Maximum complete UTF-8 document size returned to the browser. */
export declare const TEXT_PREVIEW_BYTES: number;
/** Maximum complete raster/PDF size returned to the browser. */
export declare const BINARY_PREVIEW_BYTES: number;
interface PreviewFormat {
    readonly kind: FilePreview['kind'];
    readonly mimeType: string;
    readonly maxBytes: number;
    readonly signature?: (bytes: Uint8Array) => boolean;
}
/** Return the stat-time preview format policy for one path, if supported. */
export declare function previewFormat(path: string): PreviewFormat | undefined;
/**
 * Convert bounded file bytes into a transport-safe preview payload.
 * @param format - extension-selected static format.
 * @param bytes - complete file content.
 * @returns a payload, or undefined when signature/UTF-8 validation fails.
 */
export declare function decodePreview(format: PreviewFormat, bytes: Uint8Array): FilePreview | undefined;
/**
 * Whether this package would render the file at `path`.
 *
 * The browser half asks before intercepting a file-open gesture: a path it
 * cannot render must reach the harness's own opener untouched, so the user
 * still gets the native behaviour they had before this plugin was installed.
 * @param path - the path the gesture would open.
 */
export declare function isPreviewablePath(path: string): boolean;
export {};
//# sourceMappingURL=preview-content.d.ts.map