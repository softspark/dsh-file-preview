/**
 * Package-owned invariant companion.
 *
 * A broken invariant is a bug in this package, never a user error, so the
 * message names the package: a stack trace in someone else's harness should
 * say whose fault it is without further digging.
 * @module @softspark/dsh-file-preview/invariant
 */
/** Fail loudly when an assumption this package owns turns out to be false. */
export declare function invariant(condition: unknown, message: string): asserts condition;
//# sourceMappingURL=invariant.d.ts.map